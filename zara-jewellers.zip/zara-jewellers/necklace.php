<div class="page">
    <div class="container">
        <div class="row">
            <div class="inner-cont">
                <div class="container" style="text-align:center; margin-bottom: 40px;">
                    <h4 class="heading">Necklace</h4>
                </div>
                <div class="col-sm-3">
                    <div class="product-box">
                        <img src="images/gallery/10.jpg" class="img-responsive" alt="">
                        <h3>Product Name <span>$$$</span></h3>
                    </div>

                </div>

                <div class="col-sm-3">
                    <div class="product-box">
                        <img src="images/gallery/11.jpg" class="img-responsive" alt="">
                        <h3>Product Name <span>$$$</span></h3>
                    </div>

                </div>

                <div class="col-sm-3">
                    <div class="product-box">
                        <img src="images/gallery/12.jpg" class="img-responsive" alt="">
                        <h3>Product Name <span>$$$</span></h3>
                    </div>

                </div>

                <div class="col-sm-3">
                    <div class="product-box">
                        <img src="images/gallery/13.jpg" class="img-responsive" alt="">
                        <h3>Product Name <span>$$$</span></h3>
                    </div>

                </div>
                <div class="clearfix"></div>

                <div class="col-sm-3">
                    <div class="product-box">
                        <img src="images/gallery/14.jpg" class="img-responsive" alt="">
                        <h3>Product Name <span>$$$</span></h3>
                    </div>

                </div>

                <div class="col-sm-3">
                    <div class="product-box">
                        <img src="images/gallery/15.jpg" class="img-responsive" alt="">
                        <h3>Product Name <span>$$$</span></h3>
                    </div>

                </div>

                <div class="col-sm-3">
                    <div class="product-box">
                        <img src="images/gallery/16.jpg" class="img-responsive" alt="">
                        <h3>Product Name <span>$$$</span></h3>
                    </div>

                </div>

                <div class="col-sm-3">
                    <div class="product-box">
                        <img src="images/gallery/17.jpg" class="img-responsive" alt="">
                        <h3>Product Name <span>$$$</span></h3>
                    </div>

                </div>
                <div class="clearfix"></div>

                <div class="col-sm-3">
                    <div class="product-box">
                        <img src="images/gallery/18.jpg" class="img-responsive" alt="">
                        <h3>Product Name <span>$$$</span></h3>
                    </div>

                </div>

                <div class="col-sm-3">
                    <div class="product-box">
                        <img src="images/gallery/19.jpg" class="img-responsive" alt="">
                        <h3>Product Name <span>$$$</span></h3>
                    </div>

                </div>

                <div class="col-sm-3">
                    <div class="product-box">
                        <img src="images/gallery/20.jpg" class="img-responsive" alt="">
                        <h3>Product Name <span>$$$</span></h3>
                    </div>

                </div>

                <div class="col-sm-3">
                    <div class="product-box">
                        <img src="images/gallery/21.jpg" class="img-responsive" alt="">
                        <h3>Product Name <span>$$$</span></h3>
                    </div>

                </div>
                <div class="clearfix"></div>

                <div class="col-sm-3">
                    <div class="product-box">
                        <img src="images/gallery/22.jpg" class="img-responsive" alt="">
                        <h3>Product Name <span>$$$</span></h3>
                    </div>

                </div>

                <div class="col-sm-3">
                    <div class="product-box">
                        <img src="images/gallery/23.jpg" class="img-responsive" alt="">
                        <h3>Product Name <span>$$$</span></h3>
                    </div>

                </div>

                

                

                <div class="col-sm-3">
                    <div class="product-box">
                        <img src="images/gallery/27.jpg" class="img-responsive" alt="">
                        <h3>Product Name <span>$$$</span></h3>
                    </div>

                </div>

                <div class="col-sm-3">
                    <div class="product-box">
                        <img src="images/gallery/28.jpg" class="img-responsive" alt="">
                        <h3>Product Name <span>$$$</span></h3>
                    </div>

                </div>

                
                <div class="clearfix"></div>
            </div>
        </div>
    </div>
</div>
<!--welcome-->