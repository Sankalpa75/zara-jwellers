<div class="page">
    <div class="container">
        <div class="row">
            <div class="inner-cont">
                <div class="container" style="text-align:center; margin-bottom: 40px;">
                    <h4 class="heading">EXCAVATION</h4>
                </div>

                <div class="col-sm-6">
                    <p class="text-justify">


                        If you’re looking for premium stone work, you can rely on VIP LANDSCAPING to deliver the best
                        quality stone and Installation workmanship. We offer decorative
                        stone work solutions to enhance the look of your walls and boost the aesthetic value of just
                        about any room, lobby or facade you want install in. Lush and exotic stone work is suitable
                        for lobbies, facades, building entries, feature walls, columns and custom-made rooms. No matter
                        where you install natural stone work, stone work will transform your space into a
                        prestigious and aesthetically pleasing masterpiece. At AM Tiling Services, we can supply a
                        custom
                        solution, the stone and Installation VIC locals will love.<br><br>


                        AM Tiling Services is fronted by an experienced stonemason that VIC residents can
                        trust
                        for quality workmanship. If you are looking to renovate or refurbish your home, add a stone
                        feature wall, or some stone
                        paving, give AM Tiling and the team at AM Tiling Services a call today.<br><br>


                        With a long list of happy and satisfied customers, you can rest assured that we are dedicated to
                        providing the highest quality stonework throughout VIC and with a personalised service that
                        cannot be rivalled.<br>
                        Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.


                    </p>
                </div>
                <div class="col-sm-6">
                    <img src="images/excavation.jpg" class="img-responsive img-thumbnail center-block"><br>

                </div>




                <div class="clearfix"></div>
            </div>
        </div>
    </div>
</div>
<!--welcome-->