<div class="page">
    <div class="container">
        <div class="row">
            <div class="inner-cont">
                <div class="container" style="text-align:center; margin-bottom: 40px;">
                    <h4 class="heading">AUTO IRRIGATION SYSTEM </h4>
                </div>

                <div class="col-sm-6">
                    <p class="text-justify">
                        Auto irrigarion system is a process which involves using liquid concrete to level out and smooth the surface
                        of a floor space to ensure that it is a uniform height and to prepare it for tiling. In many
                        cases, Auto irrigarion system is also used to create falls, which are directional levels for drainage
                        purposes. Auto irrigarion system is considered the foundation to ensuring a tiling project results in a
                        perfect finish.<br><br>

                        Auto irrigarion system is essential to many aspects of tiling because it is unfortunately common that fresh
                        slabs in new home developments may not be poured correctly and thus be out of level. Also in
                        established homes where a renovation is undertaken, the structure may have moved over time due
                        to the ground underneath, causing floors or walls or ceilings to be slightly out of level which
                        then in turn affects the quality of the finished tiling work. Areas affected include, but are
                        not limited to: shower bases, balconies, structural levelling of main floor areas in bathrooms,
                        living rooms and kitchens. So call us now to get professional screeding service for your home.
                        then in turn affects the quality of the finished tiling work. Areas affected include, but are
                        not limited to: shower bases, balconies, structural levelling of main floor areas in bathrooms,
                        living rooms and kitchens. So call us now to get professional screeding service for your home.

                        Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
                    </p>
                </div>
                <div class="col-sm-6">
                    <img src="images/auto-irrigation-system.jpg" class="img-responsive img-thumbnail center-block"><br>

                </div>




                <div class="clearfix"></div>
            </div>
        </div>
    </div>
</div>
<!--welcome-->