<div class="page">
    <div class="container">
        <div class="row">
            <div class="inner-cont">
                <div class="container" style="text-align:center; margin-bottom: 40px;">
                    <h4 class="heading">Product</h4>
                </div>
                <div class="col-sm-4">
                    <a href="./">
                        <img src="images/product1.jpg" class="img-responsive" alt="">
                        <div class="product-content">
                            <h3>NECKLACE</h3>
                            <div class="line"></div>
                        </div>
                    </a>
                </div>

                <div class="col-sm-4">
                    <a href="./">
                        <img src="images/product2.jpg" class="img-responsive" alt="">
                        <div class="product-content">
                            <h3>RINGS</h3>
                            <div class="line"></div>
                        </div>
                    </a>
                </div>

                <div class="col-sm-4">
                    <a href="./">
                        <img src="images/product3.jpg" class="img-responsive" alt="">
                        <div class="product-content">
                            <h3>EARRINGS</h3>
                            <div class="line"></div>
                        </div>
                    </a>
                </div>
                <div class="clearfix"></div>
            </div>
        </div>
    </div>
</div>
<!--welcome-->