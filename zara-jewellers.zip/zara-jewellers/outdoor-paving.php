<div class="page">
    <div class="container">
        <div class="row">
            <div class="inner-cont">
                <div class="container" style="text-align:center; margin-bottom: 40px;">
                    <h4 class="heading">OUTDOOR PAVING</h4>
                </div>

                <div class="col-sm-6">
                    <p class="text-justify">
                        We all want to decorate the region surrounding our houses. Outdoor paving is a wonderful option
                        in this
                        regard. It not only adds beauty to our homes but
                        also makes us feel secure and proud. Moreover, Outdoor paving can also add value to your home
                        and as well to commercial spaces.<br><br>

                        It is extremely essential to maintain the surrounds of one’s residence. This is because it is
                        the main point of fascination for those who visit your home. If it is organized in a proper
                        manner, it leaves an excellent impression in the visitors’ mind. Hence, one needs AM Tiling
                        Services the contractor of quality workmanship. We play a significant role in
                        the beautification of your home whether it is large or small, we will be at our creative
                        best.<br><br>


                        AM Tiling Services offers high-quality outdoor paving solutions. We will also
                        offer great ideas on how the job can be done effectively. You will certainly notice a
                        significant difference with the company’s high standards. We will also assist you with meeting
                        your budget requirements for paving extension, or surface renovation in the future.<br><br>

                        If you want high-quality outdoor paving it is a wise decision to contact AM Tiling Services as
                        your company
                        of choice. We are efficient. A lot of individuals think this costs a lot of cash, give AM Tiling
                        Services a
                        call for a quote, there are many advantages that come with the cost.
                    </p>
                </div>
                <div class="col-sm-6">
                    <img src="images/paving.jpg" class="img-responsive img-thumbnail center-block"><br>

                </div>




                <div class="clearfix"></div>
            </div>
        </div>
    </div>
</div>
<!--welcome-->