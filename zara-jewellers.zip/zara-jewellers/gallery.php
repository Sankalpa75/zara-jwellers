<div class="page">

    <div class="container">

        <div class="row">
            <div class="page-content">
                <div class="inner-cont">
                    <div class="container" style="text-align:center">
                        <h4 class="heading" style="margin: 20px 0;">OUR GALLERY</h4>
                    </div><br>



                    <div id="gallery" style="display:none;">

                        <a href="#">

                            <img alt="Zara Jewellers" src="images/gallery/1.jpg" data-image="images/gallery/1.jpg"
                                data-description="" style="display:none">

                        </a>

                        <a href="#">

                            <img alt="Zara Jewellers" src="images/gallery/2.jpg" data-image="images/gallery/2.jpg"
                                data-description="" style="display:none">

                        </a>

                        <a href="#">

                            <img alt="Zara Jewellers" src="images/gallery/3.jpg" data-image="images/gallery/3.jpg"
                                data-description="" style="display:none">

                        </a>

                        
                                                                      

                    </div>



                    <script type="text/javascript">





                    </script>

                    <br>
                    <div class="clearfix"></div>
                </div>
            </div>
        </div>

    </div>

</div>