<div id="owl-demo" class="owl-carousel owl-theme">

    <div class="item">
        <div class="banner-content">
            <img src="images/b1.jpg">
            <div class="centered  hidden-xs">
                <h1>NEW & BETTER DESIGNS</h1>
                <p>MADE FROM CUTTING EDGE TECHNOLOGY</p>
                <a href="./about"><button class="button2">Learn More</button></a>
            </div>
        </div>
    </div>

    <div class="item">
        <div class="banner-content">
            <img src="images/b2.jpg">
            <div class="centered  hidden-xs">
                <h1>NEW & BETTER DESIGNS</h1>
                <p>MADE FROM CUTTING EDGE TECHNOLOGY</p>
                <a href="./about"><button class="button2">Learn More</button></a>
            </div>
        </div>
    </div>

    <div class="item">
        <div class="banner-content">
            <img src="images/b3.jpg">
            <div class="centered  hidden-xs">
                <h1>NEW & BETTER DESIGNS</h1>
                <p>MADE FROM CUTTING EDGE TECHNOLOGY</p>
                <a href="./about"><button class="button2">Learn More</button></a>
            </div>
        </div>
    </div>

    <div class="item">
        <div class="banner-content">
            <img src="images/b4.jpg">
            <div class="centered  hidden-xs">
                <h1>NEW & BETTER DESIGNS</h1>
                <p>MADE FROM CUTTING EDGE TECHNOLOGY</p>
                <a href="./about"><button class="button2">Learn More</button></a>
            </div>
        </div>
    </div>

</div>