<div class="page">
    <div class="container">
        <div class="row">
            <div class="inner-cont">
                <div class="container" style="text-align:center; margin-bottom: 40px;">
                    <h4 class="heading">Ring</h4>
                </div>
                <div class="col-sm-3">
                    <div class="product-box">
                        <img src="images/gallery/25.jpg" class="img-responsive" alt="">
                        <h3>Product Name <span>$$$</span></h3>
                    </div>

                </div>
                
                <div class="clearfix"></div>
            </div>
        </div>
    </div>
</div>
<!--welcome-->